<!DOCTYPE html>
<html>
<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <title>Convertidor Temperatura</title>
    <meta name="viewport" content="width=device-width, initial-scale=1">
</head>
<body>
    <h1>El área de un triángulo</h1>
    <form action="resultado1area.php">
        <p>
            <label for="base">Base:</label>
            <input type="text" name="base" id="altura"/>
        </p>
        <p>
            <label for="altura">Altura:</label>
            <input type="text" name="altura" id="altura"/>
        </p>
        <p>
            <input type="submit" value="Calcular"/>
        </p>
    </form>
</body>
</html>